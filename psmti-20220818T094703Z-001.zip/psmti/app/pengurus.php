<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class pengurus extends Model
{
    //
    protected $fillable = array('isi');
    public $timestamps = false;
}
