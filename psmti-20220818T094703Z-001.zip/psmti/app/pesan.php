<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class pesan extends Model
{
    //
     protected $fillable = array('nama', 'isi','telepon', 'hp','subject','email');
}
